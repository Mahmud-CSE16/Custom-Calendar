class Calculation{

  // number of days in month [JAN, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC]
  final List<int> _monthDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

  // month keys in order [JAN, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC]
  final List<int> _monthKeys = [1, 4, 4, 0, 2, 5, 0, 3, 6, 1, 4, 6];

  // week days values in array-index order [0, 1, 2, 3, 4, 5, 6]
  final List<String> _weekDaysValues = ['SAT', 'SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI'];

  //century codes
  final Map<String, int> _centuryCodes = {
    '1700': 4,
    '1800': 2,
    '1900': 0,
    '2000': 6
  };

  List<int> getCalendar(int month, int year){
    List<int> dates = List<int>();
    int totalDays = _monthDays[month - 1];
    int weekDay;

    if(_isLeapYear(year) && month == 2) totalDays++;

    for(int i=0; i<totalDays; i++){
      weekDay = _getWeekDay(i+1, month, year);
      if(i == 0){
        if(weekDay == 0){
          for(int j=0; j<6; j++){
            dates.add(0);
          }
        }
        else{
          for(int j=0; j<weekDay-1; j++){
            dates.add(0);
          }
        }
      }
      dates.add(i+1);
    }
    return dates;
  }

  int _getWeekDay(int day, int month, int year){
    int yearLast2Digit = year % 100;

    int res = (yearLast2Digit ~/ 4) + day + _monthKeys[month - 1];
    if(_isLeapYear(year) && (month == 1 || month == 2)) res--;
    print('${year.toString().substring(0, 2)}00');
    res += _centuryCodes['${year.toString().substring(0, 2)}00'];
    res += yearLast2Digit;
    res %= 7;
    // print(res);
    // print(_weekDaysValues[res]);
    return res;
  }

  bool _isLeapYear(int year){
    if(year % 4 == 0){
      if(year % 100 == 0){
        if(year % 400 == 0) return true;
        return false;
      }
      return true;
    }
    return false;
  }

}