import 'package:custom_calendar/calculation.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home: MyApp()));
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

  DateTime currentDateTime;
  int currentMonth;
  int currentYear;
  List<int> sequentialDates;
  int _selectedDate;
  final List<String> _weekDays = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
  final List<String> _monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  @override
  void initState() {
    super.initState();
    currentDateTime = DateTime.now();
    _selectedDate = currentDateTime.day;
    currentMonth = currentDateTime.month;
    currentYear = currentDateTime.year;
    sequentialDates = Calculation().getCalendar(currentDateTime.month, currentDateTime.year);
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          height: 350,
          width: double.infinity,
          margin: EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: Colors.blue,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              // header
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Row(
                  children: <Widget>[
                    // prev month button
                    _toggleMonths(false),
                    // month and year
                    Expanded(
                      child: Center(
                        child: Text(
                          '${_monthNames[currentMonth-1]} $currentYear',
                          style: TextStyle(color: Colors.white, fontSize: 18),
                        ),
                      ),
                    ),
                    // next month button
                    _toggleMonths(true),
                  ],
                ),
              ),
              Container(
                width: double.infinity,
                height: 1,
                color: Colors.black,
              ),
              Expanded(child: _calendar()),
            ],
          ),
        ),
      ),
    );
  }

  // next / prev month buttons
  Widget _toggleMonths(bool isNext) {
    return InkWell(
      onTap: (){
        if(isNext){
          if(currentMonth == 12) {
            currentMonth = 1;
            currentYear++;
          }
          else currentMonth++;
        }
        else{
          if(currentMonth == 1){
            currentMonth = 12;
            currentYear--;
          }
          else currentMonth--;
        }
        sequentialDates = Calculation().getCalendar(currentMonth, currentYear);
        setState(() {});
      },
      child: Container(
        padding: EdgeInsets.all(14),
        decoration: BoxDecoration(
            color: Colors.blue,
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: Colors.white.withOpacity(0.5)),
            boxShadow: [
              BoxShadow(
                color: Colors.white.withOpacity(0.2),
                offset: Offset(-3, -3),
                spreadRadius: 3,
                blurRadius: 3,
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                offset: Offset(3, 3),
                spreadRadius: 3,
                blurRadius: 3,
              ),
            ]),
        child: Icon(
          (isNext) ? Icons.arrow_forward_ios : Icons.arrow_back_ios,
          color: Colors.white,
        ),
      ),
    );
  }

  // calendar
  Widget _calendar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20),
      child: GridView.builder(
        itemCount: sequentialDates.length + 7,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          mainAxisSpacing: 20,
          crossAxisCount: 7,
          crossAxisSpacing: 20,
        ), 
        itemBuilder: (context, index){
          if(index < 7) return _calendarHeader(index);
          if(sequentialDates[index - 7] == _selectedDate) 
            return _selector(sequentialDates[index - 7]);
          return _calendarElement(sequentialDates[index - 7]);
        },
      ),
    );
  }

  // calendar header
  Widget _calendarHeader(int index){
    return Center(
      child: Text(_weekDays[index], style: TextStyle(color: Colors.white),),
    );
  }

  // calendar element
  Widget _calendarElement(int label){
    return InkWell(
      onTap: (){
        if(label > 0) setState(() => _selectedDate = label);
      },
      child: Center(
        child: Text(
          (label == 0) ? '' : '$label', 
          style: TextStyle(color: Colors.white.withOpacity((label < currentDateTime.day) ? 0.5 : 0.8),),
        )
      ),
    );
  }

  // date selector
  Widget _selector(int label) {
    return Container(
      width: 30,
      height: 30,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(50),
        border: Border.all(color: Colors.white, width: 4),
        gradient: LinearGradient(
          colors: [Colors.black.withOpacity(0.1), Colors.white],
          stops: [0.1, 1],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.9),
          borderRadius: BorderRadius.circular(50),
        ),
        child: Center(
          child: Text(
            '$label',
            style: TextStyle(
              color: Colors.blue,
            ),
          ),
        ),
      ),
    );
  }

  Future<DateTime> showDatePickerDialog(context,
      {DateTime startTime, DateTime endTime}) {
    DateTime today = DateTime.now();
    return showDatePicker(
        context: context,
        initialDate: today,
        firstDate: startTime?.subtract(Duration(days: 1)) ??
            DateTime(today.year - 100),
        lastDate: endTime ?? today.add(Duration(days: 1)),
        builder: (BuildContext context, Widget child) {
          return Theme(
            data: Theme.of(context).copyWith(
              primaryColor: Colors.blue.withOpacity(0.5),
              accentColor: Colors.white,
              // dialogBackgroundColor: Colors.blue,
            ),
            child: child,
          );
        });
  }
}
